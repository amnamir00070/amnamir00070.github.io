function openSearch() {
    document.getElementById("myOverlay").style.display = "block";
    document.getElementById("bgFade").style.display = "none";    
  }
  
  function closeSearch() {
    document.getElementById("myOverlay").style.display = "none";
    document.getElementById("bgFade").style.display = "block";
  }


  